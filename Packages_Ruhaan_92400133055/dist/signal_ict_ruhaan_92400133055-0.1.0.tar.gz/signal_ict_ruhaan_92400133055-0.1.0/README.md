Signal ICT Package

A Python package for signal processing with unitary and trigonometric signals.

## Installation

```bash
pip install signal-ICT-Ruhaan-92400133055

Usage
pythonfrom signal_ICT_Ruhaan_92400133055 import unitary_signals, trigonometric_signals, operations


Features

Unitary signal processing
Trigonometric signal operations
Signal manipulation operations